// vanaf 09:00 uur tot 21:00 uur
const colorsHeel = ["green", "blue", "purple", "red"];
const colorsHalf = ["red", "grey", "yellow", "orange"];

function getTime() {
    const now = new Date();
    const hour = now.getHours();
    const minute = now.getMinutes();
    const second = now.getSeconds();
    return `${hour}:${minute < 10 ? '0' + minute : minute}.${second < 10 ? '0' + second : second}`;
}

async function updateTime() {
    document.getElementById('time').innerText = getTime();
}

function fillTime() {
    const fillUpcoming1 = document.getElementById('fill-upcoming-1');
    const fillUpcoming2 = document.getElementById('fill-upcoming-2');
    const timeNow1 =  document.getElementById('fill-timeNow-1');
    const timeNow2 =  document.getElementById('fill-timeNow-2');

    const now = new Date();
    const hour = now.getHours();
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();
    let halfTime = null;
    let heelTime = null;
    let timeNowHeel = null;
    let timeNowHalf = null;

    // Achtergrondkleuren instellen
    switch (hour) {
        case 12:
            halfTime = colorsHalf[0]; // Kleur voor half uur
            heelTime = colorsHeel[0]; // Kleur voor heel uur
            timeNowHalf = colorsHalf[1];
            timeNowHeel = colorsHeel[1];
            break;
        case 17:
            if (minutes >= 30) {
                halfTime = colorsHalf[3]; // Kleur voor half uur
                timeNowHalf = colorsHalf[2];
            } else {
                halfTime = colorsHalf[2]; // Kleur voor half uur
                timeNowHalf = colorsHalf[1];
            }
            heelTime = colorsHeel[2]; // Kleur voor heel uur
            timeNowHeel = colorsHeel[1];
            break;
        case 18:
            if (minutes >= 30) {
                halfTime = colorsHalf[4]; // Kleur voor half uur
                timeNowHalf = colorsHalf[3];
            } else {
                halfTime = colorsHalf[3]; // Kleur voor half uur
                timeNowHalf = colorsHalf[2];
            }
            heelTime = colorsHeel[3];
            timeNowHeel = colorsHeel[2];
        break;
    }

    // percentage half uur
    let percentageHalf;

    if (minutes < 30) {
        const secondsSinceLastHalfHour = ((minutes % 30) + 30) * 60 + seconds;
        percentageHalf = (secondsSinceLastHalfHour / 3600) * 100;
    } else {
        const secondsSinceLastHalfHour = (minutes % 30) * 60 + seconds;
        percentageHalf = (secondsSinceLastHalfHour / 3600) * 100;
    }

    // percentage heel uur
    const totalSeconds = (minutes * 60) + seconds;
    const percentage = (totalSeconds / 3600) * 100;

    // Vul de balken op basis van de percentages
    if (percentageHalf > percentage) {
        fillUpcoming1.innerHTML = percentageHalf.toFixed(2) + '%';
        fillUpcoming1.style.width = `${percentageHalf}%`;
        fillUpcoming1.style.backgroundColor = halfTime; // Kleur instellen voor de hoogste balk
    
        fillUpcoming2.innerHTML = percentage.toFixed(2) + '%';
        fillUpcoming2.style.width = `${percentage}%`;
        fillUpcoming2.style.backgroundColor = heelTime; // Kleur instellen voor de laagste balk
    
        // Vul timeNow1 en timeNow2 in
        timeNow1.innerHTML = percentageHalf.toFixed(2) + '%';
        timeNow1.style.width = `${percentageHalf}%`;
        timeNow1.style.backgroundColor = timeNowHalf;
    
        timeNow2.innerHTML = percentage.toFixed(2) + '%';
        timeNow2.style.width = `${percentage}%`;
        timeNow2.style.backgroundColor = timeNowHeel;
    } else {
        fillUpcoming1.innerHTML = percentage.toFixed(2) + '%';
        fillUpcoming1.style.width = `${percentage}%`;
        fillUpcoming1.style.backgroundColor = heelTime; // Kleur instellen voor de hoogste balk
    
        fillUpcoming2.innerHTML = percentageHalf.toFixed(2) + '%';
        fillUpcoming2.style.width = `${percentageHalf}%`;
        fillUpcoming2.style.backgroundColor = halfTime; // Kleur instellen voor de laagste balk
    
        // Vul timeNow1 en timeNow2 in
        timeNow1.innerHTML = percentage.toFixed(2) + '%';
        timeNow1.style.width = `${percentage}%`;
        timeNow1.style.backgroundColor = timeNowHeel;
    
        timeNow2.innerHTML = percentageHalf.toFixed(2) + '%';
        timeNow2.style.width = `${percentageHalf}%`;
        timeNow2.style.backgroundColor = timeNowHalf;
    }
    

    // Vul timeNow1 en timeNow2 met de huidige half en heel uur kleuren en percentages

}




setInterval(fillTime, 1000);
setInterval(updateTime, 1000);
